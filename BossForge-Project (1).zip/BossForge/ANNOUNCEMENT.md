# 📢 NEW SERVER UPDATE: BOSSFORGE IS HERE!

A brand-new Boss Forge event system has arrived!

✨ **What's new?**

- A custom **Boss Forge** block with its own 3×3 crafting menu.
- **7 unique boss eggs**: Grove, Stone, Copper, Iron, Golden, Diamond, and Netherite.
- Every egg recipe can be crafted **only once globally**. Once the first player crafts it, that recipe locks for the whole server.
- Each egg summons a themed, peaceful guardian challenge.
- Boss spawn coordinates are announced in chat.
- A boss progress bar tracks the server's contributions.
- The player who contributes the most supplies earns that event's exclusive relic.
- Offline winners receive their relic when they next join.

🛠️ **Boss Forge recipe**

```text
Obsidian   Diamond      Obsidian
Iron Block Crafting Table Iron Block
Obsidian   Diamond      Obsidian
```

🎁 **Admin help:** Ask a server admin for a Boss Forge. The admin commands are available with `/bossforge help`.

Good luck collecting the seven relics, and remember: each egg recipe is a one-time server-wide craft!
