# BossForge — Paper 1.21.11

BossForge adds a special crafting station, seven globally one-time boss-event eggs, server-wide location announcements, contribution tracking, and commemorative relic rewards.

> **Event style:** The guardians are peaceful, invulnerable villager NPCs. Players complete supply-delivery challenges rather than fighting them. The player who contributes the most supplies receives the event relic.

## Requirements

- Paper 1.21.11 (Java Edition)
- Java 21
- ViaVersion on the Paper server for per-player client-version detection
- ViaBackwards is optional and requires ViaVersion if older clients are allowed to join

Minecraft Java 1.21.11 is protocol 774. The plugin shows custom event features only to clients at protocol 774 or newer when ViaVersion is installed. If ViaVersion is missing, players are treated as native clients of the server version. Older clients can still join if the server's compatibility setup permits it, but the plugin hides event guardians and suppresses BossForge announcements for them.

**Compatibility caveat:** Vanilla item stacks can be transferred between players, so an older client might still see a custom-named egg or relic as an ordinary item if another player hands it over. The plugin blocks older clients from using event eggs and opening the Forge GUI; complete per-viewer item replacement would need packet-level item virtualization.

## Build

On Windows, run `build.bat` or `build.ps1`. The script uses Gradle if installed; otherwise it downloads Gradle 8.14.3. The first build also downloads the Paper API dependency, so the build computer needs internet access.

```text
build/libs/BossForge-1.0.0.jar
```

On Linux/macOS, install Gradle 8.14.3 or newer and run:

```sh
./build.sh
```

## Install

1. Build the project.
2. Copy `build/libs/BossForge-1.0.0.jar` into the Paper server's `plugins` folder.
3. Install ViaVersion. Install ViaBackwards too only if older client versions should be allowed to connect.
4. Restart the server.
5. Give an administrator a Boss Forge with `/bossforge giveforge <player>`.
6. Place it and right-click it to open the custom 3×3 crafting GUI.

## Boss Forge recipe

Craft this in a normal crafting table:

```text
O  D  O
I  C  I
O  D  O
```

| Symbol | Item | Amount |
|---|---|---:|
| O | Obsidian | 4 |
| D | Diamond | 2 |
| I | Iron Block | 2 |
| C | Crafting Table | 1 |

Result: **1 Boss Forge** (a specially tagged Smithing Table).

## The seven boss egg recipes

All seven eggs are crafted only inside the custom Boss Forge GUI. Put all nine ingredients into the exact 3×3 pattern shown. The centre slot is always a normal egg.

### 1. Wooden / Grove Guardian Egg

```text
G  A  G
M  E  M
G  A  G
```

- G = Gold Block ×4
- A = Amethyst Block ×2
- M = Emerald Block ×2
- E = Egg ×1

### 2. Stone / Granite Golem Egg

```text
I  H  I
D  E  D
I  S  S
```

- I = Iron Block ×3
- H = custom **Grove Heart** ×1
- D = Diamond ×2
- S = Echo Shard ×2
- E = Egg ×1

### 3. Copper / Storm Sentinel Egg

```text
C  A  C
L  E  L
C  S  A
```

- C = Copper Block ×3
- A = Amethyst Block ×2
- L = Lightning Rod ×2
- S = custom **Stone Core** ×1
- E = Egg ×1

### 4. Iron / Iron Warden Egg

```text
I  T  I
R  E  R
D  I  D
```

- I = Iron Block ×3
- T = custom **Storm Core** ×1
- R = Redstone Block ×2
- D = Diamond Block ×2
- E = Egg ×1

### 5. Golden / Sunforged Champion Egg

```text
G  B  Q
Q  E  B
G  W  G
```

- G = Gold Block ×3
- B = Blaze Rod ×2
- Q = Ghast Tear ×2
- W = custom **Iron Core** ×1
- E = Egg ×1

### 6. Diamond / Crystal Colossus Egg

```text
D  N  D
O  E  O
D  G  N
```

- D = Diamond Block ×3
- N = Netherite Scrap ×2
- O = End Crystal ×2
- G = custom **Golden Core** ×1
- E = Egg ×1

### 7. Netherite / Nether Tyrant Egg

```text
N  W  A
A  E  W
N  D  N
```

- N = Netherite Ingot ×3
- W = Wither Skeleton Skull ×2
- A = Ancient Debris ×2
- D = custom **Diamond Core** ×1
- E = Egg ×1

### Custom core tokens

The six named cores are custom-tagged items, not ordinary versions of their base materials. An administrator can issue them with `/bossforge givecore <player> <core>`. Valid core IDs are `grove_heart`, `stone_core`, `storm_core`, `iron_core`, `golden_core`, and `diamond_core`.

This first build does not add natural world-generation or chest loot for cores; server staff distribute them. The recipes are independent: no boss needs to be completed before another egg can be crafted.

## One-time crafting rule

- Each of the seven egg recipes can be crafted **once globally on the server**.
- The first successful craft consumes the ingredients and permanently locks that tier's recipe in `plugins/BossForge/config.yml`.
- The lock survives restarts.
- Each tier has its own lock; crafting one egg does not lock the other six.
- Admins can reopen one recipe with `/bossforge unlock <tier>` or reopen all seven with `/bossforge reset`.
- `/bossforge giveegg` is an admin override and does not change the global craft lock.

## Event mechanics

1. Right-click a block while holding a boss egg. The egg is consumed and its matching peaceful guardian appears.
2. The plugin broadcasts the world and XYZ coordinates to eligible clients (1.21.11+ when ViaVersion is installed).
3. A boss bar tracks the event's supply progress.
4. Players right-click the guardian while holding the requested supply item to contribute it.
5. The player with the highest total contribution receives the matching commemorative relic. Ties stay with the player who first reached the tied total.
6. If the winner is offline at completion, their relic is stored and delivered when they next join. `/bossforge claim` can also claim pending rewards.

| Egg tier | Event guardian | Supply target | Required amount | Relic |
|---|---|---|---:|---|
| Wooden | Grove Guardian | Oak Logs | 48 | Grove Crest |
| Stone | Granite Golem | Cobblestone | 48 | Stone Seal |
| Copper | Storm Sentinel | Copper Ingots | 32 | Copper Medallion |
| Iron | Iron Warden | Iron Ingots | 32 | Iron Emblem |
| Golden | Sunforged Champion | Gold Ingots | 24 | Golden Sigil |
| Diamond | Crystal Colossus | Diamonds | 12 | Diamond Star |
| Netherite | Nether Tyrant | Netherite Scraps | 6 | Ancient Crown |

## Commands

| Command | Permission | Purpose |
|---|---|---|
| `/bossforge help` | Everyone | Show help |
| `/bossforge claim` | Player | Claim pending relics |
| `/bossforge giveforge <player>` | `bossforge.admin` | Give a Boss Forge |
| `/bossforge giveegg <player> <tier>` | `bossforge.admin` | Give an egg (bypasses recipe lock) |
| `/bossforge givecore <player> <core>` | `bossforge.admin` | Give a custom core token |
| `/bossforge unlock <tier>` | `bossforge.admin` | Unlock one egg recipe |
| `/bossforge reset` | `bossforge.admin` | Unlock all seven egg recipes |

Valid tiers: `wood`, `stone`, `copper`, `iron`, `gold`, `diamond`, `netherite`.

## Announcement text

See `ANNOUNCEMENT.md` for a ready-to-post server announcement.
